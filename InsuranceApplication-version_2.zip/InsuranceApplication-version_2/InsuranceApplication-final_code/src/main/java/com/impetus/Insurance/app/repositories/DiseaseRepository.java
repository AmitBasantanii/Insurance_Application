package com.impetus.insurance.app.repositories;

import com.impetus.insurance.app.models.Disease;
import com.impetus.insurance.app.models.enums.DiseaseType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DiseaseRepository extends JpaRepository<Disease, Integer> {
    Disease findByDiseaseType(DiseaseType diseaseType);
}
