package com.impetus.insurance.app.controllers;

import com.impetus.insurance.app.services.AuthenticationService;
import com.impetus.insurance.app.models.User;
import com.impetus.insurance.app.payload.AuthenticationRequest;
import com.impetus.insurance.app.payload.AuthenticationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import static com.impetus.insurance.app.constants.AuthConstants.LOGIN;
import static com.impetus.insurance.app.constants.AuthConstants.REGISTER;

@RestController
@RequiredArgsConstructor
public class AuthController {
    private final AuthenticationService authenticationService;

    /**
     * Registers a new user.
     *
     * @param user The user object containing registration details.
     * @return ResponseEntity containing the authentication response.
     */
    @PostMapping(REGISTER)
    public ResponseEntity<AuthenticationResponse> register(@RequestBody User user) {
        return ResponseEntity.ok(authenticationService.register(user));
    }

    /**
     * Logs in a user.
     *
     * @param authenticationRequest The authentication request containing user credentials.
     * @return ResponseEntity containing the authentication response.
     */
    @PostMapping(LOGIN)
    public ResponseEntity<AuthenticationResponse> login(@RequestBody AuthenticationRequest authenticationRequest) {
        return ResponseEntity.ok(authenticationService.login(authenticationRequest));
    }
}
