package com.impetus.insurance.app.mail;

import com.impetus.insurance.app.models.Application;
import com.impetus.insurance.app.models.User;


public interface NotificationService {
    void sendNotification(Application application, User user, String sub, String msg);

}
