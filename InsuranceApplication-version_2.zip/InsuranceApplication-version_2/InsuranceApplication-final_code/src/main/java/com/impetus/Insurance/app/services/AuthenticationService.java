package com.impetus.insurance.app.services;

import com.impetus.insurance.app.models.User;
import com.impetus.insurance.app.payload.AuthenticationRequest;
import com.impetus.insurance.app.payload.AuthenticationResponse;

public interface AuthenticationService {
    AuthenticationResponse register(User user);

    AuthenticationResponse login(AuthenticationRequest authenticationRequest);

}
