package com.impetus.insurance.app.models.enums;

public enum PremiumType {
    MONTHLY,
    QUARTERLY,
    YEARLY
}
