package com.impetus.insurance.app.models.enums;

public enum Relation {
    PARENTS ,
    SPOUSE,
    CHILDREN
}
