package com.impetus.insurance.app.models.enums;

public enum ApplicationStatus {
    APPROVED, REJECTED, PENDING, NEW
}
