package com.impetus.insurance.app.services;

import com.impetus.insurance.app.models.Application;

import java.util.List;

public interface ApplicationService {

    List<Application> getAllApplications();

    List<Application> getApplicationByUserId(int userId);

    Application createApplication(Application application, int userId);

    void deleteApplication(int applicationId);
}
