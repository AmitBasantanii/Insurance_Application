package com.impetus.insurance.app.services;

import com.impetus.insurance.app.models.User;

public interface AdminService {

    User createAdmin(User admin);

    User createUnderwriter(User underwriter);

    void deleteUnderwriter(int underwriterId);

    void deleteAdmin(int adminId);

}
