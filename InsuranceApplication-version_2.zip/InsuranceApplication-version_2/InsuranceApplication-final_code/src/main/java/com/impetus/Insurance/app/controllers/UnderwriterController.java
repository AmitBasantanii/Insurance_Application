package com.impetus.insurance.app.controllers;


import com.impetus.insurance.app.constants.AccessConstants;
import com.impetus.insurance.app.constants.UnderwriterUrls;
import com.impetus.insurance.app.models.Application;
import com.impetus.insurance.app.models.User;
import com.impetus.insurance.app.models.enums.ApplicationStatus;
import com.impetus.insurance.app.services.UnderwriterService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.impetus.insurance.app.constants.AppConstant.APPLICATION_APPROVED_SUCCESS;
import static com.impetus.insurance.app.constants.AppConstant.APPLICATION_REJECTED_SUCCESS;
import static com.impetus.insurance.app.constants.AppConstant.STATUS;

@RestController
@AllArgsConstructor
@PreAuthorize(AccessConstants.HAS_ROLE_UNDERWRITER)
public class UnderwriterController {

    public final UnderwriterService underwriterService;

    /**
     * Approves an application.
     *
     * @param applicationId The ID of the application to approve.
     * @return ResponseEntity with a success message.
     */
    @PutMapping(UnderwriterUrls.APPROVE_APPLICATION)
    public ResponseEntity<String> approveApplication(@PathVariable int applicationId) {
        underwriterService.approveApplications(applicationId);
        return ResponseEntity.ok(APPLICATION_APPROVED_SUCCESS);
    }

    /**
     * Rejects an application.
     *
     * @param applicationId The ID of the application to reject.
     * @return ResponseEntity with a success message.
     */
    @PutMapping(UnderwriterUrls.REJECT_APPLICATION)
    public ResponseEntity<String> rejectApplication(@PathVariable int applicationId) {
        underwriterService.rejectApplication(applicationId);
        return ResponseEntity.ok(APPLICATION_REJECTED_SUCCESS);
    }

    /**
     * Retrieves all applications assigned to the underwriter.
     *
     * @return ResponseEntity with a list of applications.
     */
    @GetMapping(UnderwriterUrls.GET_ALL_APPLICATIONS)
    public ResponseEntity<List<Application>> getAllApplicationsByUnderwriterId() {

        User underWriter = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        List<Application> applications = underwriterService.getAllApplications(underWriter.getId());
        return ResponseEntity.ok(applications);
    }

    /**
     * Retrieves applications of an underwriter by status.
     *
     * @param status The status of the applications to retrieve.
     * @return ResponseEntity with a list of applications.
     */
    @GetMapping(UnderwriterUrls.GET_APPLICATION_OF_UNDERWRITER_BY_STATUS)
    public ResponseEntity<List<Application>> getApplicationsByStatusForUnderwriter(@PathVariable(STATUS) String status) {
        User underWriter = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ApplicationStatus applicationStatus;
        try {
            applicationStatus = ApplicationStatus.valueOf(status.toUpperCase());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }

        List<Application> applications = underwriterService.getApplicationsByStatusForUnderwriter(underWriter.getId(), applicationStatus);
        return ResponseEntity.ok(applications);
    }
}