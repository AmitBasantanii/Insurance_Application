package com.impetus.insurance.app.services;

public interface SystemService {
    void AutoApproval();

}
