package com.impetus.insurance.app.models.enums;

public enum PolicyType {
    LIFE ,
    DENTAL
}
